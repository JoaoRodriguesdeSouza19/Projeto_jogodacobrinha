    let estado = "off"; // off = parado, on = ativo

    // --- Classe Palavra ---
    class Palavra {
      constructor(texto, significado) {
        this.texto = texto;
        this.letras = texto.split("");
        this.significado = significado;
      }
    }

    const palavras = [
      new Palavra('banana', 'Uma fruta amarela e doce que se come fácil.'),
      new Palavra('abacaxi', 'Uma fruta grande, com casca dura e doce por dentro.'),
      new Palavra('amarelo', 'A cor do sol e da banana.'),
      new Palavra('tomate', 'Uma fruta vermelha que se usa na comida.'),
      new Palavra('sapato', 'O que usamos nos pés para andar.'),
      new Palavra('telefone', 'Um aparelho que usamos para falar com alguém longe.'),
      new Palavra('elefante', 'Um animal muito grande com tromba e orelhas grandes.'),
      new Palavra('caderno', 'Um caderno para escrever e desenhar.'),
      new Palavra('janela', 'A abertura na parede por onde entra luz e ar.'),
      new Palavra('boneca', 'Um brinquedo que parece uma pessoa pequena.'),
      new Palavra('pipoca', 'Milho que estoura no fogo e fica gostoso para comer.'),
      new Palavra('bicicleta', 'Um veículo de duas rodas que se pedala para andar.'),
      new Palavra('chuveiro', 'O lugar onde a água cai para tomar banho.'),
      new Palavra('abajur', 'Uma luz que fica em cima da mesa para iluminar.'),
      new Palavra('chocolate', 'Doce feito de cacau, muito gostoso de comer.')
    ];

    // --- Classe Jogador ---
    class Jogador {
      constructor(velocidade = 0) {
        this.velocidade = velocidade;
        this.tamanho = 0;
        this.posicao = { x: 0, y: 0 };
        this.direcao = null;
        this.fase = 3;
      }
      mover() {
        if (!this.direcao) return;
        if (this.direcao === "up") this.posicao.y -= this.velocidade;
        if (this.direcao === "down") this.posicao.y += this.velocidade;
        if (this.direcao === "left") this.posicao.x -= this.velocidade;
        if (this.direcao === "right") this.posicao.x += this.velocidade;
      }
    }

    // --- Classe Fase ---
    class Fase {
      constructor(numero, bolinhasLaranja = [], bolinhasVerde = [], bolinhasRoxa = []) {
        this.numero = numero;
        this.bolinhasLaranja = bolinhasLaranja;
        this.bolinhasVerde = bolinhasVerde;
        this.bolinhasRoxa = bolinhasRoxa;
      }
    }

    // --- Definição das fases ---
    const fases = [
  new Fase(1, [], [], []),

  // Fase 2
  // Roxa: topo-direita (X grande, Y entre topo e meio)
  // Verde: inferior-esquerda (X pequeno, Y oposto da roxa)
  new Fase(
    2,
    [], // laranja
    [ { x: 50, y: 350 } ], // verde inferior esquerda
    [ { x: 700, y: 100 } ] // roxo topo direita
  ),

  // Fase 3
  // Verde: ponta esquerda meio
  // Laranja: centro da tela
  // Roxo: ponta direita meio
  new Fase(
    3,
    [ { x: 400, y: 250 } ], // laranja centro
    [ { x: 50, y: 250 } ],  // verde ponta esquerda
    [ { x: 750, y: 250 } ]  // roxo ponta direita
  ),

  // Fase 4 - mantém posições anteriores como exemplo
  new Fase(
    4, 
    [ { x: 100, y: 150 }, { x: 400, y: 150 }, { x: 200, y: 400 }, { x: 500, y: 350 } ],
    [ { x: 150, y: 250 }, { x: 350, y: 200 } ],
    [ { x: 250, y: 300 }, { x: 450, y: 100 } ]
  ),

  // Fase 5 - mantém posições anteriores
  new Fase(
    5, 
    [ { x: 80, y: 100 }, { x: 250, y: 200 }, { x: 420, y: 300 }, { x: 600, y: 150 }, { x: 350, y: 400 } ],
    [ { x: 150, y: 150 }, { x: 300, y: 250 }, { x: 500, y: 350 } ],
    [ { x: 100, y: 200 }, { x: 400, y: 100 }, { x: 550, y: 250 } ]
  )
];

    const jogador = new Jogador();
    const divJogador = document.getElementById("jogador");
    const infoDiv = document.getElementById("info");
    const bolinha = document.getElementById("bolinha");

    let seguidores = [];
    let history = [];

    // --- Atualização da tela ---
    function atualizarTela() {
      divJogador.style.left = jogador.posicao.x + "px";
      divJogador.style.top = jogador.posicao.y + "px";
    }

    // --- Checagem de colisões ---
    function checarColisoes() {
      const jogadorRect = divJogador.getBoundingClientRect();
      const botoes = document.querySelectorAll('button:not(#controls button)');

      botoes.forEach(botao => {
        const botaoRect = botao.getBoundingClientRect();
        if (
          jogadorRect.left < botaoRect.right &&
          jogadorRect.right > botaoRect.left &&
          jogadorRect.top < botaoRect.bottom &&
          jogadorRect.bottom > botaoRect.top
        ) {
          jogador.tamanho++;
          document.getElementById('tamanho').textContent = 'Cliques: ' + jogador.tamanho;
          botao.remove();
          criarSeguidor();
        }
      });
    }

    // --- Criação de seguidores ---
    function criarSeguidor() {
      const seg = document.createElement("div");
      seg.classList.add("seguidor");
      document.body.appendChild(seg);
      seguidores.push(seg);
    }

    // --- Loop principal ---
    function loop() {
      jogador.mover();
      atualizarTela();
      if (estado === "on") checarColisoes();

      history.push({ x: jogador.posicao.x, y: jogador.posicao.y });
      if (history.length > 1000) history.shift();

      seguidores.forEach((seg, index) => {
        let delay = (index + 1) * 20;
        if (history.length > delay) {
          let pos = history[history.length - delay];
          seg.style.left = pos.x + "px";
          seg.style.top = pos.y + "px";
        }
      });

      requestAnimationFrame(loop);
    }
    loop();

    // --- Função para criar bolinhas de qualquer tipo ---
    function criarBolinhas(faseAtual) {
      document.querySelectorAll('.bolinhaFase').forEach(b => b.remove());

      const criar = (cor, array) => {
        array.forEach(pos => {
          const b = document.createElement('div');
          b.classList.add('bolinhaFase');
          b.style.left = pos.x + 'px';
          b.style.top = pos.y + 'px';
          b.style.background = cor;
          b.style.width = '50px';
          b.style.height = '50px';
          b.style.borderRadius = '50%';
          document.body.appendChild(b);
          iniciarCicloBola(b);
        });
      }

      criar('orange', faseAtual.bolinhasLaranja);
      criar('green', faseAtual.bolinhasVerde);
      criar('purple', faseAtual.bolinhasRoxa);
    }

    // --- Ciclo de expansão e piscada ---
    function iniciarCicloBola(bola) {
      const tamanhoInicial = 50;
      const tamanhoFinal = tamanhoInicial * 2;

      const ciclo = () => {
        if (estado === "off") { bola.style.display = 'none'; return; }

        // Bolinha desaparece
        bola.style.display = 'none';

        // Aparece de novo após 1s
        setTimeout(() => {
          bola.style.display = 'block';
          bola.style.width = tamanhoInicial + 'px';
          bola.style.height = tamanhoInicial + 'px';
        }, 1000);

        // Expande após 2s
        setTimeout(() => {
          bola.style.width = tamanhoFinal + 'px';
          bola.style.height = tamanhoFinal + 'px';
        }, 3000);

        setTimeout(ciclo, 5000);
      }

      ciclo();
    }

    // --- Função unificada para palavra e fase ---
    function gerarPalavraEFase() {
      if (estado === "off") return;

      // Remove botões antigos
      const antigos = document.querySelectorAll('button:not(#controls button)');
      antigos.forEach(b => b.remove());

      // Sorteia palavra
      const index = Math.floor(Math.random() * palavras.length);
      const palavra = palavras[index];

      // Atualiza info
      infoDiv.innerHTML = `
        <strong>${palavra.texto.toUpperCase()}</strong>
        <span>${palavra.significado}</span>
      `;

      // Cria botões das letras
      const bodyWidth = window.innerWidth;
      const bodyHeight = window.innerHeight;
      palavra.letras.forEach(letra => {
        const botao = document.createElement('button');
        botao.textContent = letra;
        const x = Math.random() * (bodyWidth - 60);
        const y = 50 + Math.random() * (bodyHeight - 60 - 50);
        botao.style.left = x + 'px';
        botao.style.top = y + 'px';
        document.body.appendChild(botao);
      });

      // Cria bolinhas da fase
      const faseAtual = fases.find(f => f.numero === jogador.fase);
      if (!faseAtual) return;
      criarBolinhas(faseAtual);
    }

    // --- Bolinha piscante central ---
    const tamanhoInicial = 50;
    const tamanhoFinal = tamanhoInicial * 2;
    function centralizarBolinha() {
      bolinha.style.left = `calc(50% - ${bolinha.offsetWidth / 2}px)`;
      bolinha.style.top = `calc(50% - ${bolinha.offsetHeight / 2}px)`;
    }
    function cicloBolinha() {
      if (estado === "off") { bolinha.style.display = 'none'; return; }

      bolinha.style.display = 'none';
      setTimeout(() => {
        bolinha.style.width = tamanhoInicial + 'px';
        bolinha.style.height = tamanhoInicial + 'px';
        bolinha.style.display = 'block';
        centralizarBolinha();
      }, 1000);

      setTimeout(() => {
        bolinha.style.width = tamanhoFinal + 'px';
        bolinha.style.height = tamanhoFinal + 'px';
        centralizarBolinha();
      }, 3000);

      setTimeout(cicloBolinha, 5000);
    }
    function iniciarBolinha() { cicloBolinha(); }

    // --- Controles do jogador ---
    document.addEventListener("keydown", (event) => {
      // Enter só ativa o jogo
      if (event.key === "Enter" && estado === "off") {
        estado = "on";
        jogador.velocidade = 5;
        jogador.direcao = "right";
        gerarPalavraEFase();
      }

      if (estado === "on") {
        if (event.key === "ArrowUp") jogador.direcao = "up";
        if (event.key === "ArrowDown") jogador.direcao = "down";
        if (event.key === "ArrowLeft") jogador.direcao = "left";
        if (event.key === "ArrowRight") jogador.direcao = "right";
      }
    });